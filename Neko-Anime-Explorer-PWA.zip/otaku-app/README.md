# Neko — Anime Explorer (PWA)

Aplikasi katalog anime responsif berbahasa Indonesia. Fitur:
- Jelajahi anime populer dan trending.
- Cari anime melalui AniList GraphQL API.
- Detail anime, sinopsis, genre, rating, tahun, dan jumlah episode.
- Watchlist lokal tersimpan di perangkat.
- Tombol pencarian opsi menonton resmi (tidak menyediakan/meng-host video).
- Bisa dipasang sebagai aplikasi web/PWA setelah di-host melalui HTTPS.

## Menjalankan
Karena browser membatasi beberapa fitur jika file dibuka langsung, jalankan lewat server lokal:

```bash
python -m http.server 8080
```

Lalu buka `http://localhost:8080` dari folder proyek. Untuk memasang di Android, deploy folder ini ke hosting HTTPS, buka URL-nya di Chrome Android, lalu pilih **Tambahkan ke layar utama / Install app**.

## Tentang API dan hak cipta
Aplikasi ini menggunakan AniList API untuk metadata katalog. File AllAnime scraper yang diberikan tidak diintegrasikan untuk mengekstrak atau mem-proxy video yang hak distribusinya belum jelas. Tombol menonton mengarahkan pengguna mencari opsi resmi yang tersedia di wilayahnya. Jika Anda memiliki API video berlisensi, integrasi player dapat ditambahkan dengan endpoint dan izin yang sesuai.

## Catatan
- Memerlukan koneksi internet.
- Data watchlist disimpan di localStorage browser pada perangkat yang sama.
- Ini adalah proyek PWA, bukan APK Android native yang sudah dikompilasi.
